package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.IEmployeeService;

public class MainUI {
	static Scanner scanner = null;
	String scheme, name, designation;
	static String choices;
	static int choice;
	int id;
	Employee emp = new Employee();
	IEmployeeService service = new EmployeeService();
	private int salary;
	boolean flag;
	static int choiceFlag = 0;
	static MainUI obj = new MainUI();

	public static void main(String[] args) {
		System.out.println("**** Welcome to Employee Medical Insurance Scheme *****");
		do {
			do {
				System.out.println("\n Services Offered :");
				System.out.println("1. Find Insurance Scheme \t\t 2. Display Your Details");
				scanner = new Scanner(System.in);
				choice = scanner.nextInt();

				switch (choice) {
				case 1:
					obj.getinsurance();
					choiceFlag = 1;
					break;
				case 2:
					if (choiceFlag == 1)
						obj.getdetails();
					else
						System.err.println("Please enter your details first");
					break;
				default:
					System.err.println("Invalid Input");
				}
			} while (choiceFlag == 0);
			System.out.println("Want to continue : (Y=yes | N=No)");
			choices = scanner.nextLine();
		} while (choices.equalsIgnoreCase("y"));

	}

	private void getdetails() {
		System.out.println("Your Details :");
		System.out.println("Name : " + emp.getName() + " ID :" + emp.getId() + " \n Designation :"
				+ emp.getDesignation() + " Scheme Alloted :" + emp.getInsuranceScheme());

	}

	private void getinsurance() {
		boolean result, result2;
		System.out.println("Enter Your Employee Details");
		System.out.println("Id :");
		scanner = new Scanner(System.in);
		id = scanner.nextInt();
		scanner = new Scanner(System.in);
		do {
			System.out.println("Name :");
			name = scanner.nextLine();
			result = service.isNamevalid(name);
			if (result) {

			}

			else
				System.out.println("Invalid Name");
		} while (!result);
		scanner = new Scanner(System.in);
		System.out.println("Salary :");
		salary = scanner.nextInt();
		scanner = new Scanner(System.in);
		do {
			System.out.println("Designation :");
			designation = scanner.nextLine();
			result2 = service.isDesignationvalid(designation);
			if (result2) {

			} else
				System.out.println("Invalid Designation");
		} while (!result2);
		System.out.println("Details Added..!!");
		emp.setName(name);
		emp.setId(id);
		emp.setDesignation(designation);

		scheme = service.getInsurance(salary, designation);
		if (scheme.equals("Invalid input")) {
			System.err.println("Not Valid Inputs provided.");
		} else {
			emp.setInsuranceScheme(scheme);
			System.out.println("Suitable insurance scheme  to  you is : " + scheme);
		}

	}

}
